#!/system/bin/bash
# Set to 0 to disable, 1 to enable
enabled=1
# Set the reading interval: (minutes)
interval=10
# Also with screen on (could cause issues)
son=0
#Toggle debugging
debug=0